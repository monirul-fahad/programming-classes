import React from 'react';

const Cart = (props) => {



    return (
        <div>
             <h2> Tour Members:{props.count}</h2>
        </div>
    );
};

export default Cart;