import './App.css';
import Home from './Pages/Home/Home/Home';


function App() {
  return (
    <div className="App">
      <Home></Home>
    </div>
  );
}

export default App;
